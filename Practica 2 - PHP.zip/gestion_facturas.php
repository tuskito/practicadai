<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">

				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";
						$resultado=mysqli_query($c,"Select * from factura");

						if(!$resultado){
							echo "Error al acceder a la base de datos de facturas.<br>";
						}
						else {

							echo "<form method=post action='INS_UP_DEL_facturas.php?multiDelete'>";
							echo "<table id='tabla_facturas' width='100%' border='0' cellpadding='0' cellspacing='0'><tr id='table_header'><th>Seleccionar</th><th>Número Factura</th><th>Matrícula</th><th>Horas</th><th>Precio Hora</th><th>Fecha Emisión</th><th>Fecha Pago</th><th>Base Imponible</th><th>iva</th><th>total</th></tr>";

							$contador=1;
							while($fila=mysqli_fetch_array($resultado)) {
								$numerofactura=$fila["numero_factura"];
								$matricula=$fila["matricula"];
								$horas=$fila["horas"];
								$preciohora=$fila["precio_hora"];
								$fechaemision=$fila["fecha_emision"];
								$fechapago=$fila["fecha_pago"];
								$baseimponible=$fila["base_imponible"];
								$iva=$fila["iva"];
								$total=$fila["total"];


								echo "<tr><td><input type='checkbox' value=$numerofactura name='delete[]'/></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$numerofactura</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$matricula</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$horas h</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$preciohora €</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$fechaemision</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$fechapago</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$baseimponible €</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$iva %</a></td><td><a class='enlace_tabla' href='factura.php?numerofactura=$numerofactura'>$total €</a></td></tr>";
							}
							echo "<tr><td colspan='10' style='background-color: #f2f2f2;'><button class='boton' type='button' onClick=location.href='insert_facturas.php'>Insertar</button></td></tr>";
							echo "<tr><td colspan='10' style='background-color: #f2f2f2;'><input type='submit' class='boton' value='Eliminar'/></td></tr>";
							echo "</table></form>";

						}
					?>
				</div>
				
			</section>
		 
		 <footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>