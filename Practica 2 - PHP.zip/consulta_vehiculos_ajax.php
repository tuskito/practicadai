<?php
  include "conexion.php";  

	$marca=$_POST["marca"]; 
  $modelo=$_POST["modelo"]; 
  $anio=$_POST["anio"]; 
   


	 header ("Content-type:text/xml");
	 header ("Cache-Control:no-cache, must-revalidate");


  $select=mysqli_query($c,"Select * from vehiculos where marca LIKE '%$marca%' AND modelo LIKE '%$modelo%' AND anio LIKE '%$anio%'");

   echo "<?xml version='1.0' encoding='UTF-8'?>";

   echo "<XML>"; 

 while($fila=mysqli_fetch_array($select)) {
		
    $matricula = $fila['matricula'];
    $marca = $fila['marca'];
    $modelo = $fila['modelo'];
    $anio = $fila['anio'];
    
  	    
	      echo "<vehiculo>";
        echo "<matricula>";
          echo "$matricula";
        echo "</matricula>";

        echo "<marca>";
          echo "$marca";
        echo "</marca>";

        echo "<modelo>";
        echo "$modelo";
        echo "</modelo>";

        ;

        echo "<anio>";
          echo "$anio";
        echo "</anio>";

        echo "</vehiculo>";
             
			 
		}
    echo "</XML>";
?>    