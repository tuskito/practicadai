<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">
				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";

						$numerofactura = $_GET["numerofactura"];
						$resultado=mysqli_query($c,"Select * from factura where numero_factura='$numerofactura'");

						if(!$resultado){
							echo "Error al acceder a la base de datos de facturas.<br>";
						}
						else {

							echo "<form method='post'><table id='tabla_detalles' width='100%' border='0' cellpadding='0' cellspacing='20'><tr><td colspan='5'><h3 style='color:#003366;'>Detalles de la factura</h3></td></tr><tr><th colspan='2'>Número de Factura</th><th colspan='3'>Matrícula</th></tr>";

							$contador=1;
							while($fila=mysqli_fetch_array($resultado)) {
								$numerofactura=$fila["numero_factura"];
								$matricula=$fila["matricula"];
								$horas=$fila["horas"];
								$preciohora=$fila["precio_hora"];
								$fechaemision=$fila["fecha_emision"];
								$fechapago=$fila["fecha_pago"];
								$baseìmponible=$fila["base_imponible"];
								$iva=$fila["iva"];
								$total=$fila["total"];

								$vehiculos=mysqli_query($c,"Select matricula from vehiculos");
								if(!$vehiculos){
									echo "Error al acceder a la base de datos de taller.<br>";
								}
								else {

									echo "<tr><td colspan='2'><input type='text' value='$numerofactura' name='numerofactura' readonly/></td><td colspan='3'><select name='matricula'>";

									while($fila=mysqli_fetch_array($vehiculos)) {
										$matricula_bd=$fila["matricula"];
										if($matricula_bd==$matricula)
											echo "<option value='$matricula_bd' selected>$matricula_bd</option>";
										else
											echo "<option value='$matricula_bd'>$matricula_bd</option>";
									}


									echo "</select></td></tr><tr><td colspan='5'><h3 style='color:#003366;'>Fechas</h3></td></tr>";
									echo "<tr><th colspan='3'>Fecha Emisión</th><th colspan='5'>Fecha Pago</th></tr>";
									echo "<tr><td colspan='3'><input type='text' value='$fechaemision' name='fechaemision'/></td><td colspan='2'><input type='text' value='$fechapago' name='fechapago'/></td></tr>";
									

									echo "<tr><td colspan='5'><h3 style='color:#003366;'>Precio</h3></td></tr>";
									echo "<tr><th>Horas</th><th>Precio Hora (€)</th><th>Base Imponible</th><th>IVA (%)</th><th>Total</th></tr>";
									echo "<tr><td><input type='text' value='$horas' name='horas'/></td><td><input type='text' value='$preciohora' name='preciohora'/></td><td><input type='text' value='$baseimponible €' name='base_imponible' readonly/></td><td><input type='text' value='$iva' name='iva'/></td><td><input type='text' value='$total €' name='total' readonly/></td></tr>";
								}
								
							}
								echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><button class='boton' formaction='INS_UP_DEL_facturas.php?update'>Modificar</button></td></tr>";
								echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><button class='boton' formaction='INS_UP_DEL_facturas.php?delete'>Eliminar</button></td></tr>";
								echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><button class='boton ancho' formaction='gestion_lineas_factura.php?numerofactura=$numerofactura'>Ver Líneas de Factura</button></td></tr>";
								echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><button class='boton ancho' formaction='factura_pdf.php'>Generar Factura PDF</button></td></tr>";
								echo "</table>";
								echo "</form>";


						}
					?>
				</div>
				
			</section>
			
			 <footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>