<?php
	session_start();
	if(isset($_SESSION['login'])) {
		if ($_SESSION["login"]==true) {
			header("Location: login.php");
		}
	}
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
		<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 
			<section class="contenido">
				<div class="news">

					<div style="width: 50%; margin-left: auto; margin-right: auto;">
						<form action="login.php" method="post" enctype="multipart/form-data">
							<label for="user" style="font-size: 16pt; font-weight: bold;">Usuario:</label>
							<input type="text" id="user" name="user" required/>
							<label for="pwd" style="font-size: 16pt; font-weight: bold;">Contraseña:</label>
							<input type="password" id="pwd" name="pwd" required/>
							<input type="submit" value="Entrar"/>
						</form>
					</div>
				</div>
				
			</section>

			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>