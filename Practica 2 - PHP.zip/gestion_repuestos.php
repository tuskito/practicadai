<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">
				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";
						$resultado=mysqli_query($c,"Select * from repuestos");

						if(!$resultado){
							echo "Error al acceder a la base de datos de repuestos.<br>";
						}
						else {

							echo "<form method=post action='INS_UP_DEL_repuestos.php?multiDelete'>";
							echo "<table id='tabla_repuestos' width='100%' border='0' cellpadding='0' cellspacing='0'><tr id='table_header'><th>Seleccionar</th><th>Referencia</th><th>Descripción</th><th>Importe</th><th>Porcentaje</th></tr><th>Fotografia</th></tr>";

							$contador=1;
							while($fila=mysqli_fetch_array($resultado)) {
								$referencia=$fila["referencia"];
								$descripcion=$fila["descripcion"];
								$importe=$fila["importe"];
								$porcentaje=$fila["porcentaje"];
								$foto=$fila["fotografia"];
								if ($foto!=null) {

								// Tratamiento de la imagen antes de mostrarla

								// getcwd devuelve el directorio actual

								// tempnam crea un archivo temporal

								// basename da nombre a un archivo

								// Creamos una archivo en www con el nombre temp

								$imagen=basename(tempnam(getcwd(),"temp"));

								// añadimos la extensión jpg al fichero

								$imagen.=".jpg";

								//abrimos el fichero con permisos de escritura

								$fichero=fopen($imagen,"w");

								// escribimos en el fichero el contenido del campo de la base de datos

								fwrite($fichero,$foto);

								//cerramos el fichero

								fclose($fichero);


								echo "<tr><td><input type='checkbox' value=$referencia name='delete[]'/></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$referencia</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$descripcion</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$importe</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$porcentaje</a></td></tr><img src=$imagen style='width:100px; height:100px;float:none;' border=0/></td></tr>";
								} else {

								echo "<tr><td><input type='checkbox' value=$referencia name='delete[]'/></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$referencia</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$descripcion</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$importe</a></td><td><a class='enlace_tabla' href='repuestos.php?referencia=$referencia'>$porcentaje</a></td></tr>img src='img/avatar.png'style='width:100px; height:100px;float:none;' border=0/></td></tr>";
								}	
								
							}
							echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><button class='boton' type='button' onClick=location.href='insert_repuestos.php'>Insertar</button></td></tr>";
								echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><input type='submit' class='boton' value='Eliminar'/></td></tr>";
							echo "</table></form>";

						}
					?>
				</div>
				
			</section>
			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>