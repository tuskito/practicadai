// FUNCIONES JAVASCRIPT
	
// Creamos el objeto AJAX httprequest

function AJAXCrearObjeto(){   
  var obj;   
  if (window.XMLHttpRequest) { // no es IE   
    obj = new XMLHttpRequest();
	//alert('El navegador no es IE');
  }     
  else { // Es IE o no tiene el objeto    
    try {   
      obj = new ActiveXObject("Microsoft.XMLHTTP");
	   // alert('El navegador utilizado es IE');
    }
    catch (e) {
      // alert('El navegador utilizado no está soportado');
    }
  }
  //alert('realizado');
  return obj;
}



function leerDatos_Clientes(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta_clientes');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Id</th><th>Nombre</th><th>Apellido 1</th><th>Apellido 2</th>" + 
    "<th>Poblacion</th><th>Provincia</th><th>Teléfono</th></tr>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('cliente').length; i++){

      item = xml.getElementsByTagName('cliente')[i];


      id = item.getElementsByTagName('id')[0].firstChild.data;
	    definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ id +"</a></td>";


      nombre = item.getElementsByTagName('nombre')[0].firstChild
      if(nombre != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ nombre.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";


      apellido1 = item.getElementsByTagName('apellido1')[0].firstChild
      if(apellido1 != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ apellido1.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";

      apellido2 = item.getElementsByTagName('apellido2')[0].firstChild
      if(apellido2 != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ apellido2.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";

      poblacion = item.getElementsByTagName('poblacion')[0].firstChild
      if(poblacion != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ poblacion.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";


      provincia = item.getElementsByTagName('provincia')[0].firstChild
      if(provincia != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ provincia.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";



      telefono = item.getElementsByTagName('telefono')[0].firstChild
      if(telefono != null){
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'>"+ telefono.data +"</a></td>";
      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='cliente.php?id=" + id + "'></a></td>";

    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta_clientes tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta_clientes th").css("background-color","#f2f2f2");
}


function leerDatos_vehiculos(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta_vehiculos');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Matricula</th><th>marca</th><th>modelo</th>" + 
    "<th>Año</th>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('vehiculo').length; i++){

      item = xml.getElementsByTagName('vehiculo')[i];


      matricula = item.getElementsByTagName('matricula')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='vehiculos.php?matricula=" + matricula + "'>"+ matricula +"</a></td>";


      marca = item.getElementsByTagName('marca')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='vehiculos.php?matricula=" + matricula + "'>"+ marca +"</a></td>";


      modelo = item.getElementsByTagName('modelo')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='vehiculos.php?matricula=" + matricula + "'>"+ modelo +"</a></td>";

      }
      else
        definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='vehiculos.php?matricula=" + matricula + "'></a></td>";
      
      anio = item.getElementsByTagName('anio')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='vehiculos.php?matricula=" + matricula + "'>"+ anio +"</a></td>";



    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta_vehiculos tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta_vehiculos th").css("background-color","#f2f2f2");
}


function leerDatos_Fact_Emitidas(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Número Factura</th>" + 
    "<th>Mano de obra</th><th>Precio Hora</th><th>Fecha Emisión</th><th>Fecha Pago</th><th>Base Imponible</th><th>IVA</th><th>Total</th></tr>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('factura').length; i++){

      item = xml.getElementsByTagName('factura')[i];


      numerofactura = item.getElementsByTagName('numerofactura')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ numerofactura +"</a></td>";


      horas = item.getElementsByTagName('horas')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ horas +"</a></td>";


      preciohora = item.getElementsByTagName('preciohora')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ preciohora +"</a></td>";


      fechaemision = item.getElementsByTagName('fechaemision')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechaemision +"</a></td>";


      fechapago = item.getElementsByTagName('fechapago')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechapago +"</a></td>";


      baseimponible = item.getElementsByTagName('baseimponible')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ baseimponible +"</a></td>";

      iva = item.getElementsByTagName('iva')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ iva +"</a></td>";

      total = item.getElementsByTagName('total')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ total +"</a></td></tr>";

    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta th").css("background-color","#f2f2f2");
}


function leerDatos_Fact_Pagadas(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Número Factura</th>" + 
    "<th>Mano de obra</th><th>Precio Hora</th><th>Fecha Emisión</th><th>Fecha Pago</th><th>Base Imponible</th><th>IVA</th><th>Total</th></tr>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('factura').length; i++){

      item = xml.getElementsByTagName('factura')[i];


      numerofactura = item.getElementsByTagName('numerofactura')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ numerofactura +"</a></td>";


      horas = item.getElementsByTagName('horas')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ horas +"</a></td>";


      preciohora = item.getElementsByTagName('preciohora')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ preciohora +"</a></td>";


      fechaemision = item.getElementsByTagName('fechaemision')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechaemision +"</a></td>";


      fechapago = item.getElementsByTagName('fechapago')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechapago +"</a></td>";


      baseimponible = item.getElementsByTagName('baseimponible')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ baseimponible +"</a></td>";

      iva = item.getElementsByTagName('iva')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ iva +"</a></td>";

      total = item.getElementsByTagName('total')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ total +"</a></td></tr>";

    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta th").css("background-color","#f2f2f2");
}


function leerDatos_Fact_Pendientes(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Número Factura</th>" + 
    "<th>Mano de obra</th><th>Precio Hora</th><th>Fecha Emisión</th><th>Fecha Pago</th><th>Base Imponible</th><th>IVA</th><th>Total</th></tr>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('factura').length; i++){

      item = xml.getElementsByTagName('factura')[i];


      numerofactura = item.getElementsByTagName('numerofactura')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ numerofactura +"</a></td>";


      horas = item.getElementsByTagName('horas')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ horas +"</a></td>";


      preciohora = item.getElementsByTagName('preciohora')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ preciohora +"</a></td>";


      fechaemision = item.getElementsByTagName('fechaemision')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechaemision +"</a></td>";


      fechapago = item.getElementsByTagName('fechapago')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechapago +"</a></td>";


      baseimponible = item.getElementsByTagName('baseimponible')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ baseimponible +"</a></td>";

      iva = item.getElementsByTagName('iva')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ iva +"</a></td>";

      total = item.getElementsByTagName('total')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ total +"</a></td></tr>";

    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta th").css("background-color","#f2f2f2");
}



function leerDatos_Fact_Clientes(){
  // Comprobamos que se han recibido los datos
  if (oXML.readyState == 4) {
    // Accedemos al XML recibido
    var xml = oXML.responseXML.documentElement;
    // Accedemos al componente html correspondiente a la tabla
    var tabla = document.getElementById('tabla_cnta');
 
    var definicion_tabla = new String("");

    // cadena con los datos para crear la tabla
    definicion_tabla ="<tr id='table_header'><th>Número Factura</th>" + 
    "<th>Mano de obra</th><th>Precio Hora</th><th>Fecha Emisión</th><th>Fecha Pago</th><th>Base Imponible</th><th>IVA</th><th>Total</th></tr>";

    var item;      
      
    for (i = 0; i < xml.getElementsByTagName('factura').length; i++){

      item = xml.getElementsByTagName('factura')[i];


      numerofactura = item.getElementsByTagName('numerofactura')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<tr><td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ numerofactura +"</a></td>";


      horas = item.getElementsByTagName('horas')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ horas +"</a></td>";


      preciohora = item.getElementsByTagName('preciohora')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ preciohora +"</a></td>";


      fechaemision = item.getElementsByTagName('fechaemision')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechaemision +"</a></td>";


      fechapago = item.getElementsByTagName('fechapago')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ fechapago +"</a></td>";


      baseimponible = item.getElementsByTagName('baseimponible')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ baseimponible +"</a></td>";

      iva = item.getElementsByTagName('iva')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ iva +"</a></td>";

      total = item.getElementsByTagName('total')[0].firstChild.data;
      definicion_tabla =definicion_tabla+"<td><a class='enlace_tabla' href='factura.php?numerofactura=" + numerofactura + "'>"+ total +"</a></td></tr>";

    }

    tabla.innerHTML = definicion_tabla;
  }
  $("#tabla_cnta tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

  $("#tabla_cnta th").css("background-color","#f2f2f2");
}



function mostrar_clientes(){  
   
  var nombre=document.getElementsByName("nombre")[0].value;
  var apellido1=document.getElementsByName("apellido1")[0].value;
  var apellido2=document.getElementsByName("apellido2")[0].value;
  var poblacion=document.getElementsByName("poblacion")[0].value;
  var provincia=document.getElementsByName("provincia")[0].value;
  var telefono=document.getElementsByName("telefono")[0].value;

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_clientes_ajax.php');

  oXML.onreadystatechange = leerDatos_Clientes;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  // oXML.send();
  oXML.send('nombre=' + nombre + '&apellido1=' + apellido1 + '&apellido2=' + apellido2 + 
  	'&poblacion=' + poblacion + '&provincia=' + provincia + '&telefono=' + telefono);
}


function mostrar_vehiculos(){  
   
  var marca=document.getElementsByName("marca")[0].value;
  var modelo=document.getElementsByName("modelo")[0].value;
  var anio=document.getElementsByName("anio")[0].value;
  var color=document.getElementsByName("color")[0].value;
  

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_vehiculos_ajax.php');

  oXML.onreadystatechange = leerDatos_vehiculos;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  // oXML.send();
  oXML.send('marca=' + marca + '&modelo=' + modelo + '&anio=' + anio '&color=' + color);
}

function mostrar_fact_emitidas(){  
   
  var fecha_ini=document.getElementsByName("fecha_ini")[0].value;
  var fecha_fin=document.getElementsByName("fecha_fin")[0].value;

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_fact_emitidas_ajax.php');

  oXML.onreadystatechange = leerDatos_Fact_Emitidas;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  // oXML.send();
  oXML.send('fecha_ini=' + fecha_ini + '&fecha_fin=' + fecha_fin);
}

function mostrar_fact_pagadas(){  
   
  var fecha_ini=document.getElementsByName("fecha_ini")[0].value;
  var fecha_fin=document.getElementsByName("fecha_fin")[0].value;

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_fact_pagadas_ajax.php');

  oXML.onreadystatechange = leerDatos_Fact_Pagadas;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  // oXML.send();
  oXML.send('fecha_ini=' + fecha_ini + '&fecha_fin=' + fecha_fin);
}


function mostrar_fact_cliente(){  
   
  var x = document.getElementById("nombres");
  var i = x.selectedIndex;
  var nombre=x.options[i].text;

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_fact_cliente_ajax.php');

  oXML.onreadystatechange = leerDatos_Fact_Clientes;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  // oXML.send();
  oXML.send('cliente=' + nombre);
}



function mostrar_fact_pendientes(){  

  oXML = AJAXCrearObjeto();
  oXML.open('POST', 'consulta_fact_pendientes_ajax.php');

  oXML.onreadystatechange = leerDatos_Fact_Pendientes;

  oXML.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

  // lanza la peticion enviando los parametros 
  oXML.send();
}