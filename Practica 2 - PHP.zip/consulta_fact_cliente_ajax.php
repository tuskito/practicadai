<?php
  include "conexion.php";  

  $nombre=$_POST["cliente"]; 

   header ("Content-type:text/xml");
   header ("Cache-Control:no-cache, must-revalidate");


  
  $select=mysqli_query($c,"Select fact.numero_factura, fact.matricula, fact.horas, fact.precio_hora, fact.fecha_emision, fact.fecha_pago, fact.base_imponible, fact.iva, fact.total from factura as fact,vehiculos as vehi,clientes as cli where fact.matricula = vehi.matricula AND vehi.id_cliente = cli.id_cliente AND cli.nombre = '$nombre'");

   echo "<?xml version='1.0' encoding='UTF-8'?>";

   echo "<XML>"; 

 while($fila=mysqli_fetch_array($select)) {
		
    $numerofactura=$fila["numero_factura"];
    $matricula=$fila["matricula"];
    $horas=$fila["horas"];
    $preciohora=$fila["precio_hora"];
    $fechaemision=$fila["fecha_emision"];
    $fechapago=$fila["fecha_pago"];
    $baseimponible=$fila["base_imponible"];
    $iva=$fila["iva"];
    $total=$fila["total"];
  	
	      echo "<factura>";
        
        echo "<numerofactura>";
          echo "$numerofactura";
        echo "</numerofactura>";

        echo "<horas>";
          echo "$horas";
        echo "</horas>";

        echo "<preciohora>";
        echo "$preciohora";
        echo "</preciohora>";

        echo "<fechaemision>";
          echo "$fechaemision";
        echo "</fechaemision>";

        echo "<fechapago>";
          echo "$fechapago";
        echo "</fechapago>";

        echo "<baseimponible>";
          echo "$baseimponible";
        echo "</baseimponible>";

        echo "<iva>";
          echo "$iva";
        echo "</iva>";

        echo "<total>";
          echo "$total";
        echo "</total>";

        echo "</factura>";
             
			 
		}
    echo "</XML>";
?>    