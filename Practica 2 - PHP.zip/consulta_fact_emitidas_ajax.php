<?php
  include "conexion.php";  

	$fecha_ini=$_POST["fecha_ini"]; 
  $fecha_fin=$_POST["fecha_fin"]; 

	 header ("Content-type:text/xml");
	 header ("Cache-Control:no-cache, must-revalidate");


  if($fecha_ini == null && $fecha_fin == null)
    $select=mysqli_query($c,"Select * from factura where fecha_emision <> '0000-00-00'");
  else if($fecha_ini == null)
    $select=mysqli_query($c,"Select * from factura where fecha_emision <='$fecha_fin' and fecha_emision <> '0000-00-00'");
  else if($fecha_fin == null)
    $select=mysqli_query($c,"Select * from factura where fecha_emision >= '$fecha_ini' and fecha_emision <> '0000-00-00'");
  else
    $select=mysqli_query($c,"Select * from factura where fecha_emision BETWEEN '$fecha_ini' AND '$fecha_fin' and fecha_emision <> '0000-00-00'");

   echo "<?xml version='1.0' encoding='UTF-8'?>";

   echo "<XML>"; 

 while($fila=mysqli_fetch_array($select)) {
		
    $numerofactura=$fila["numero_factura"];
    $matricula=$fila["matricula"];
    $horas=$fila["horas"];
    $preciohora=$fila["precio_hora"];
    $fechaemision=$fila["fecha_emision"];
    $fechapago=$fila["fecha_pago"];
    $baseimponible=$fila["base_imponible"];
    $iva=$fila["iva"];
    $total=$fila["total"];
  	
	      echo "<factura>";
        
        echo "<numerofactura>";
          echo "$numerofactura";
        echo "</numerofactura>";

        echo "<horas>";
          echo "$horas";
        echo "</horas>";

        echo "<preciohora>";
        echo "$preciohora";
        echo "</preciohora>";

        echo "<fechaEmision>";
          echo "$fechaEmision";
        echo "</fechaEmision>";

        echo "<fechapago>";
          echo "$fechapago";
        echo "</fechapago>";

        echo "<baseimponible>";
          echo "$baseimponible";
        echo "</baseimponible>";

        echo "<iva>";
          echo "$iva";
        echo "</iva>";

        echo "<total>";
          echo "$total";
        echo "</total>";

        echo "</factura>";
             
			 
		}
    echo "</XML>";
?>    