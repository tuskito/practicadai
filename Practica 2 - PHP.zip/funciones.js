
// ******************* PHP ******************* //

$(document).ready(function(){
    $("#tabla_clientes tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });
    $("#tabla_vehiculos tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

    $("#tabla_repuestos tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

     $("#tabla_facturas tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });

      $("#tabla_lineas_factura tr").hover(function(){
        $(this).css("background-color", "#ccccff");
        }, function(){
        $(this).css("background-color", "");
    });