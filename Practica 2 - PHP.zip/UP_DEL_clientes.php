<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehículos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">

				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";

						if(isset($_GET['update'])) {

							$id = $_POST["id"];
							$dni = $_POST["dni"];
							$nombre = $_POST["nombre"];
							$apellido1 = $_POST["apellido1"];
							$apellido2 = $_POST["apellido2"];

							$direccion = $_POST["direccion"];
							$cp = $_POST["cp"];
							$poblacion = $_POST["poblacion"];
							$provincia = $_POST["provincia"];
							
							$telefono = $_POST["telefono"];
							$email = $_POST["email"];

							$update=mysqli_query($c,"Update clientes SET id_cliente=$id,dni='$dni',nombre='$nombre',apellido1='$apellido1',apellido2='$apellido2',direccion='$direccion',cp='$cp',poblacion='$poblacion',provincia='$provincia',telefono='$telefono',`e-mail`='$email' WHERE id_cliente=$id");

							if(!$update)
								echo "Error al acceder a la base de datos de clientes.<br>";
							else 
								echo "Actualización realizada con exito.";

							header("Refresh:1; url=gestion_clientes.php");
						}
						else if(isset($_GET['delete'])) {
							$id = $_POST["id"];
							$delete=mysqli_query($c,"DELETE from clientes WHERE id_cliente=$id");

							if(!$delete)
								echo "Error al acceder a la base de datos de clientes.<br>";
							else 
								echo "Eliminación realizada con exito.";

							header("Refresh:1; url=gestion_clientes.php");
						}
						else if(isset($_GET['multiDelete'])) {
							if(isset($_POST['delete'])){
								$array_borrados=$_POST["delete"];
								$error=0;
								for($i=0;$i<count($array_borrados);$i++)
								{
									$multi_delete=mysqli_query($c,"DELETE from clientes WHERE id_cliente=$array_borrados[$i]");
									if($multi_delete==0)
									{
										echo "<br><br>Error al eliminar el cliente de la base de datos.";
										$error=1;
									}
								}
								if($error==0)
								{
									echo "Los clientes se han eliminado correctamente.";
								}

								header("Refresh:1; url=gestion_clientes.php");
							} else{
								echo "Seleccione un cliente antes de eliminar.";
								header("Refresh:2; url=gestion_clientes.php");
							}
						}
						else if(isset($_GET['insert'])) {
							if(isset($_POST['id'])){
								$id = $_POST["id"];
								$dni = $_POST["dni"];
								$nombre = $_POST["nombre"];
								$apellido1 = $_POST["apellido1"];
								$apellido2 = $_POST["apellido2"];

								$direccion = $_POST["direccion"];
								$cp = $_POST["cp"];
								$poblacion = $_POST["poblacion"];
								$provincia = $_POST["provincia"];
								
								$telefono = $_POST["telefono"];
								$email = $_POST["email"];

								if (is_uploaded_file($_FILES['foto']['tmp_name']))
								 {
   									$image = addslashes(file_get_contents($_FILES['foto']['tmp_name']));
   									$insert=mysqli_query($c,"insert into clientes values
									('$id','$dni','$nombre','$apellido1','$apellido2','$direccion','$cp','$poblacion','$provincia'
									,'$telefono','$email','{$image}')");

								}
								else
									$insert=mysqli_query($c,"insert into clientes (id_cliente,dni,nombre,apellido1,apellido2,direccion,cp,poblacion,provincia,telefono,e-mail) values
									('$id','$dni','$nombre','$apellido1','$apellido2','$direccion','$cp','$poblacion','$provincia'
									,'$telefono','$email')");

								if(!$insert)
									echo "Error al acceder a la base de datos de clientes.<br>";
								else 
									echo "Insercción realizada con exito.";

								header("Refresh:1; url=gestion_clientes.php");
							} else
								header("Location: gestion_clientes.php");
							
						}
						else 
							header("Location: gestion_clientes.php");
						
					?>
				</div>

			</section>

			</section>

			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>