<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">
				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");
						
						include "conexion.php";

						$resultado=mysqli_query($c,"Select Max(referencia) as ref from repuestos");

						if(!$resultado){
							echo "Error al acceder a la base de datos de Repuestos.<br>";
						}
						else {
							
							$fila=mysqli_fetch_array($resultado);
							$ref=$fila["ref"];
							for ($n=0; $n<1; $n++) {
    						++$ref . PHP_EOL;
							};
						

							echo "<form  action='INS_UP_DEL_repuestos.php?insert' method='post'><table id='tabla_detalles' width='100%' border='0' cellpadding='0' cellspacing='20'><tr><td colspan='4'><h3 style='color:#003366;'>Detalles del repuesto</h3></td></tr><tr><th>Referencia</th><th>Descripción</th><th>Importe</th><th>porcentaje</th></tr>";

							echo "<tr><td><input type='text' value='$ref' name='referencia' readonly/></td><td><input type='text' name='descripcion'/></td><td><input type='text' name='importe'/></td><td><input type='text' name='porcentaje'/></td></tr>";	

							echo "<tr><td colspan='5'><h3 style='color:#003366;'>Fotografía</h3></td></tr>";
							echo "<tr><td></td><td colspan='3'><input type='file' name='foto' ></td></tr>";
							echo "<tr><td colspan='5' style='background-color: #f2f2f2;'><input class='boton' type='submit' value='Insertar Repuesto'/></td></tr>";
							echo "</table>";
							echo "</form>";
						}
					?>
				</div>
				
			</section>
			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>