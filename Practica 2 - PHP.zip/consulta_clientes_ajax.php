<?php
  include "conexion.php";  

	$nombre=$_POST["nombre"]; 
  $apellido1=$_POST["apellido1"]; 
  $apellido2=$_POST["apellido2"]; 
  $poblacion=$_POST["poblacion"]; 
  $provincia=$_POST["provincia"]; 
  $telefono=$_POST["telefono"]; 


	 header ("Content-type:text/xml");
	 header ("Cache-Control:no-cache, must-revalidate");



  $select=mysqli_query($c,"Select * from clientes where nombre LIKE '%$nombre%' AND apellido1 LIKE '%$apellido1%' AND apellido2 LIKE '%$apellido2%' AND poblacion LIKE '%$poblacion%' AND provincia LIKE '%$provincia%' AND telefono LIKE '%$telefono%'");
  
   echo "<?xml version='1.0' encoding='UTF-8'?>";

   echo "<XML>"; 

 while($fila=mysqli_fetch_array($select)) {
		
    $id = $fila['id_cliente'];
    $nombre = $fila['nombre'];
    $apellido1 = $fila['apellido1'];
    $apellido2 = $fila['apellido2'];
    $poblacion = $fila['poblacion'];
    $provincia = $fila['provincia'];
    $telefono = $fila['telefono'];
  	    
	      echo "<cliente>";
        echo "<id>";
          echo "$id";
        echo "</id>";

        echo "<nombre>";
          echo "$nombre";
        echo "</nombre>";

        echo "<apellido1>";
        echo "$apellido1";
        echo "</apellido1>";

        echo "<apellido2>";
          echo "$apellido2";
        echo "</apellido2>";

        echo "<poblacion>";
          echo "$poblacion";
        echo "</poblacion>";

        echo "<provincia>";
          echo "$provincia";
        echo "</provincia>";

        echo "<telefono>";
          echo "$telefono";
        echo "</telefono>";

        echo "</cliente>";
             
			 
		}
    echo "</XML>";
?>    