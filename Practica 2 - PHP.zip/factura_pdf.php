<?php
require('fpdf/fpdf.php');

class PDF_reciept extends FPDF { 
	function __construct ($orientation = 'P', $unit = 'pt', $format = 'Letter', $margin = 40) { 
	        parent::__construct($orientation, $unit, $format, $margin);

	    $this->SetTopMargin($margin); 
	    $this->SetLeftMargin($margin); 
	    $this->SetRightMargin($margin); 
	    $this->SetAutoPageBreak(true, $margin); 
	} 


	function Header() { 
	    $this->SetFont('Arial', 'B', 20); 
	    $this->SetFillColor(36, 96, 84); 
	    $this->SetTextColor(225); 
	    $this->SetXY(250,10); 
	   
	    
		$this->SetXY(45,60); 
	    $this->Cell(0, 30, "Tu taller al mejor precio", 0, 1, 'C', true); 
	}

	function Footer() { 
	    $this->SetFont('Arial', '', 12); 
	    $this->SetTextColor(0); 
	    $this->SetXY(35,-60); 
	    $this->Cell(0, 20, "Gracias por haber comprado en talleres Gallego", 'T', 0, 'C'); 
	}

	function PriceTable($products, $units, $prices_ind , $prices, $total, $horas, $preciohora, $iva) { 
	    $this->SetFont('Arial', 'B', 12); 
	    $this->SetTextColor(0); 
	    $this->SetFillColor(36, 140, 129); 
	    $this->SetLineWidth(1); 
	    $this->Cell(235, 25, "Ref Repuesto", 'LTR', 0, 'C', true); 
	    $this->Cell(100, 25, "unidades", 'LTR', 0, 'C', true); 
	    $this->Cell(100, 25, "importe Indv", 'LTR', 0, 'C', true); 
	    $this->Cell(100, 25, "importe Total", 'LTR', 1, 'C', true); 
	 
	    $this->SetFont('Arial', ''); 
	    $this->SetFillColor(238); 
	    $this->SetLineWidth(0.2); 
	    $fill = false; 

	    for ($i = 0; $i < count($products); $i++) { 
	        $this->Cell(235, 20, $products[$i], 1, 0, 'L', $fill); 
	        $this->Cell(100, 20, $units[$i], 1, 0, 'L', $fill); 
	        $this->Cell(100, 20, $prices_ind[$i] . ' ' . chr(128), 1, 0, 'R', $fill); 
	        $this->Cell(100, 20, $prices[$i] . ' ' . chr(128), 1, 1, 'R', $fill); 
	        $fill = !$fill; 
	    } 

	    $this->SetX(375); 
	    $this->SetFont('Arial', 'B', 12); 
	    $this->SetTextColor(0); 
	    $this->SetFillColor(36, 140, 129); 
	    $this->SetLineWidth(1); 
	    $this->Cell(100, 20, "horas", 'LTR', 0, 'C', true); 
	    $this->SetFont('Arial', ''); 
	    $this->SetFillColor(238); 
	    $this->SetLineWidth(0.2); 
	    $this->Cell(100, 20, $horas . ' horas', 1, 0, 'R'); 

		$this->Ln();
	    $this->SetX(375); 
	    $this->SetFont('Arial', 'B', 12); 
	    $this->SetTextColor(0); 
	    $this->SetFillColor(36, 140, 129); 
	    $this->SetLineWidth(1); 
	    $this->Cell(100, 20, "precio hora", 'LTR', 0, 'C', true); 
	    $this->SetFont('Arial', ''); 
	    $this->SetFillColor(238); 
	    $this->SetLineWidth(0.2); 
	    $this->Cell(100, 20, $preciohora . ' ' . chr(128), 1, 0, 'R'); 

	    $this->Ln();
	    $this->SetX(375); 
	    $this->SetFont('Arial', 'B', 12); 
	    $this->SetTextColor(0); 
	    $this->SetFillColor(36, 140, 129); 
	    $this->SetLineWidth(1); 
	    $this->Cell(100, 20, "iva", 'LTR', 0, 'C', true); 
	    $this->SetFont('Arial', ''); 
	    $this->SetFillColor(238); 
	    $this->SetLineWidth(0.2); 
	    $this->Cell(100, 20, $iva . ' %', 1, 0, 'R'); 

	    $this->Ln();
	    $this->SetX(375); 
	    $this->SetFont('Arial', 'B', 12); 
	    $this->SetTextColor(0); 
	    $this->SetFillColor(36, 140, 129); 
	    $this->SetLineWidth(1); 
	    $this->Cell(100, 20, "total", 'LTRB', 0, 'C', true); 
	    $this->SetFont('Arial', ''); 
	    $this->SetFillColor(238); 
	    $this->SetLineWidth(0.2); 
	    $this->Cell(100, 20, $total . ' ' . chr(128), 1, 0, 'R'); 
	}

}

include "conexion.php";

$matricula = $_POST["matricula"];
$numerofactura = $_POST["numerofactura"];
$resultado=mysqli_query($c,"Select cli.nombre, cli.apellido1, cli.direccion, cli.poblacion, cli.provincia,cli.cp from factura as fact,vehiculos as vehi,clientes as cli where fact.matricula ='$matricula' AND vehi.id_cliente = cli.id_cliente AND fact.numero_factura='$numerofactura'");



if(!$resultado){
	echo "Error al acceder a la base de datos de facturas.<br>";
}
else {
	$fila=mysqli_fetch_array($resultado);
	$nombre=$fila["nombre"];
	$apellido1=$fila["apellido1"];
	$direccion=$fila["direccion"];
	$poblacion=$fila["poblacion"];
	$provincia=$fila["provincia"];
	$cp=$fila["cp"];

	$pdf = new PDF_reciept(); 
	$pdf->AddPage(); 
	$pdf->SetFont('Arial', 'B', 12);
	$pdf->SetY(100);


	$pdf->Cell(100, 13, "Pedido por:"); 
	$pdf->SetFont('Arial', ''); 


	$pdf->Cell(200, 13, $nombre.' '.$apellido1);


	$pdf->SetFont('Arial', 'B', 12); 
	$pdf->Cell(75, 13, 'Fecha:'); 
	$pdf->SetFont('Arial', ''); 
	$pdf->Cell(100, 13, date('F j, Y'), 0, 1);


	$pdf->SetX(140); 
	$pdf->Cell(200, 13, $matricula,0,2);
	$pdf->SetFont('Arial', 'I'); 
	$pdf->Cell(200, 15, $direccion, 0, 2); 
	$pdf->Cell(200, 15, $poblacion . ', ' . $provincia, 0, 2); 
	$pdf->Cell(200, 15, $cp . ' ' . 'Spain'); 
	$pdf->Ln(100);


	$array_ref = array();
	$array_unidades = array();
	$array_importe = array();
	$array_importe_total = array();

	$rs_lineas_fact=mysqli_query($c,"Select * from detalle_factura where numero_factura='$numerofactura'");
	while($fila=mysqli_fetch_array($rs_lineas_fact)) {
		$referencia=$fila["referencia"];
		$unidades=$fila["unidades"];


		$rs_total=mysqli_query($c,"Select * from repuestos where referencia='$referencia'");
		$fila=mysqli_fetch_array($rs_total);
		$importe=$fila["importe"];
		$porcentaje=$fila["porcentaje"];

		array_push($array_ref,$referencia);
		array_push($array_unidades,$unidades);

		$total_ind = $importe + $importe*($porcentaje/100);
		array_push($array_importe,$total_ind);

		$total = ($importe*$unidades) + ($importe*$unidades)*($porcentaje/100);
		array_push($array_importe_total,$total);

		
	}
	$total = $_POST["total"];
	$horas = $_POST["horas"];
	$preciohora = $_POST["preciohora"];
	$iva = $_POST["iva"];

	$pdf->PriceTable($array_ref, $array_unidades, $array_importe, $array_importe_total, intval($total), $horas, $preciohora, $iva);

	$pdf->Ln(100);
	$message = "Gracias por comprar en TALLERES GALLEGO, por favor mantenga imprimida o guardada esta factura para posteriores tramites o problemas encontrados en el producto, es altamente indispensable hacerlo."; 
	$pdf->MultiCell(0, 15, $message);

	$pdf->Output();
}
?>