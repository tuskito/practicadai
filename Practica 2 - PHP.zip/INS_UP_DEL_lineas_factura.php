<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">	
				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";

						if(isset($_GET['update'])) {
							$id=$_POST["id"];
							$numerofactura=$_POST["numerofactura"];
							$referencia=$_POST["referencia"];
							$unidades=$_POST["unidades"];

							$rs_lineas_fact=mysqli_query($c,"Select * from detalle_factura where id_det_dactura='$id'");
								$fila=mysqli_fetch_array($rs_lineas_fact);
								$ref_antigua=$fila["referencia"];
								$unidades_antigua=$fila["unidades"];


							$rs_total_antigua=mysqli_query($c,"Select * from repuestos where referencia='$ref_antigua'");
								$fila=mysqli_fetch_array($rs_total_antigua);
								$importe_antigua=$fila["importe"];
								$porcentaje_antigua=$fila["porcentaje"];


							$total_antigua= ($importe_antigua*$unidades_antigua) + ($importe_antigua*$unidades_antigua)*($porcentaje_antigua/100);

							

							$update=mysqli_query($c,"Update detalle_factura SET id_det_dactura='$id',numero_factura='$numerofactura',referencia='$referencia',unidades='$unidades' WHERE id_det_dactura='$id'");


							$rs_total=mysqli_query($c,"Select * from repuestos where referencia='$referencia'");
								$fila=mysqli_fetch_array($rs_total);
								$importe=$fila["importe"];
								$porcentaje=$fila["porcentaje"];



							$rs_baseimponible=mysqli_query($c,"Select horas, precio_hora, iva, base_imponible from factura where numero_factura='$numerofactura'");
								$fila=mysqli_fetch_array($rs_baseimponible);
								$horas=$fila["horas"];
								$preciohora=$fila["precio_hora"];
								$iva=$fila["iva"];
								$baseimponible_fact=$fila["base_imponible"];



								$total= ($importe*$unidades) + ($importe*$unidades)*($porcentaje/100);
   								$baseimponible = $total;

   								$baseimponible -= $total_antigua;

   								$baseimponible += $baseimponible_fact;

   								$total_factura = $baseimponible + ($baseimponible*($iva/100));

   								$update=mysqli_query($c,"Update factura SET base_imponible='$baseimponible', Total='$total_factura' WHERE numero_factura='$numerofactura'");

							if(!$update)
								echo "Error al acceder a la base de datos de lineas de facturas.<br>";
							else 
								echo "Actualización realizada con exito.";

							header("Refresh:1; url=gestion_lineas_factura.php?numerofactura=$numerofactura");
						}
						else if(isset($_GET['delete'])) {
							$id=$_POST["id"];
							$numerofactura=$_POST["numerofactura"];

							$rs_lineas_fact=mysqli_query($c,"Select * from detalle_factura where id_det_dactura='$id'");
								$fila=mysqli_fetch_array($rs_lineas_fact);
								$ref_antigua=$fila["referencia"];
								$unidades_antigua=$fila["unidades"];


							$rs_total_antigua=mysqli_query($c,"Select * from repuestos where referencia='$ref_antigua'");
								$fila=mysqli_fetch_array($rs_total_antigua);
								$importe_antigua=$fila["importe"];
								$porcentaje_antigua=$fila["porcentaje"];

							$rs_baseimponible=mysqli_query($c,"Select horas, precio_hora, base_imponible, iva from factura where numero_factura='$numerofactura'");
								$fila=mysqli_fetch_array($rs_baseimponible);
								$baseimponible=$fila["base_imponible"];
								$iva=$fila["iva"];
								$horas=$fila["horas"];
								$preciohora=$fila["precio_hora"];


							$total_antigua= ($importe_antigua*$unidades_antigua) + ($importe_antigua*$unidades_antigua)*($porcentaje_antigua/100);

							$delete=mysqli_query($c,"DELETE from detalle_factura WHERE id_det_dactura='$id'");

							if(!$delete)
								echo "Error al acceder a la base de datos de lineas de facturas.<br>";
							else {
								$baseimponible -= ($total_antigua+($horas*$preciohora));

   								$total_factura = $baseimponible + ($baseimponible*($iva/100));

   								$update=mysqli_query($c,"Update factura SET base_imponible='$baseimponible', Total='$total_factura' WHERE numero_factura='$numerofactura'");
								echo "Eliminación realizada con exito.";
							}

							header("Refresh:1; url=gestion_lineas_factura.php?numerofactura=$numerofactura");
						}
						else if(isset($_GET['multiDelete'])) {
							$numerofactura=$_POST["numerofactura"];
							if(isset($_POST['delete'])){
								$array_borrados=$_POST["delete"];
								$error=0;

								$rs_baseimponible=mysqli_query($c,"Select horas, precio_hora, base_imponible, iva from factura where numero_factura='$numerofactura'");
										$fila=mysqli_fetch_array($rs_baseimponible);
										$baseimponible=$fila["base_imponible"];
										$iva=$fila["iva"];
										$horas=$fila["horas"];
										$preciohora=$fila["precio_hora"];

								for($i=0;$i<count($array_borrados);$i++)
								{
									$rs_lineas_fact=mysqli_query($c,"Select * from detalle_factura where id_det_dactura='$array_borrados[$i]'");
										$fila=mysqli_fetch_array($rs_lineas_fact);
										$ref_antigua=$fila["referencia"];
										$unidades_antigua=$fila["unidades"];


									$rs_total_antigua=mysqli_query($c,"Select * from repuestos where referencia='$ref_antigua'");
										$fila=mysqli_fetch_array($rs_total_antigua);
										$importe_antigua=$fila["importe"];
										$porcentaje_antigua=$fila["porcentaje"];
									

									$total_antigua= ($importe_antigua*$unidades_antigua) + ($importe_antigua*$unidades_antigua)*($porcentaje_antigua/100);


									$multi_delete=mysqli_query($c,"DELETE from detalle_factura WHERE id_det_dactura='$array_borrados[$i]'");
									if($multi_delete==0)
									{
										echo "<br>Error al eliminar la linea de la factura de la base de datos.";
										$error=1;
									}
									else
										$baseimponible -= ($total_antigua+($horas*$preciohora));
								}
								if($error==0)
								{
									

	   								$total_factura = $baseimponible + ($baseimponible*($iva/100));

	   								$update=mysqli_query($c,"Update factura SET base_imponible='$baseimponible', Total='$total_factura' WHERE numero_factura='$numerofactura'");
									echo "La linea de la factura se han eliminado correctamente.";
								}

								header("Refresh:1; url=gestion_lineas_factura.php?numerofactura=$numerofactura");
							} else{
								echo "Seleccione una linea de la factura antes de eliminar.";
								header("Refresh:2; url=gestion_lineas_factura.php?numerofactura=$numerofactura");
							}
						}
						else if(isset($_GET['insert'])) {
							$numerofactura=$_POST["numerofactura"];
							if(isset($_POST['id'])){
								$id=$_POST["id"];
								$referencia=$_POST["referencia"];
								$unidades=$_POST["unidades"];
							
   								$insert=mysqli_query($c,"insert into detalle_factura values ('$id','$numerofactura','$referencia','$unidades')");



								$rs_total=mysqli_query($c,"Select * from repuestos where referencia='$referencia'");
								$fila=mysqli_fetch_array($rs_total);
								$importe=$fila["importe"];
								$porcentaje=$fila["porcentaje"];



								$rs_baseimponible=mysqli_query($c,"Select horas, precio_hora, iva, base_imponible from factura where numero_factura='$numerofactura'");
								$fila=mysqli_fetch_array($rs_baseimponible);
								$horas=$fila["horas"];
								$preciohora=$fila["precio_hora"];
								$iva=$fila["iva"];
								$baseimponible_fact=$fila["base_imponible"];



								$total= ($importe*$unidades) + ($importe*$unidades)*($porcentaje/100);
   								$baseimponible = $total;

   								$baseimponible += $baseimponible_fact;

   								$total_factura = $baseimponible + ($baseimponible*($iva/100));

   								$update=mysqli_query($c,"Update factura SET base_imponible='$baseimponible', Total='$total_factura' WHERE numero_factura='$numerofactura'");




								if(!$insert)
									echo "Error al acceder a la base de datos de lineas de factura.<br>";
								else 
									echo "Insercción realizada con exito.";



								header("Refresh:1; url=gestion_lineas_factura.php?numerofactura=$numerofactura");
							}
							else
								header("Location: gestion_lineas_factura.php?numerofactura=$numerofactura");
						}
						else 
							header("Location: gestion_facturas.php");
						
					?>
				</div>
				
			</section>

			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>