<?php
  include "conexion.php";  

	$fecha_ini=$_POST["fecha_ini"]; 
  $fecha_fin=$_POST["fecha_fin"]; 

	 header ("Content-type:text/xml");
	 header ("Cache-Control:no-cache, must-revalidate");

  if($fecha_ini == null && $fecha_fin == null)
    $select=mysqli_query($c,"Select * from factura where Fecha_Pago <> '0000-00-00'");
  else if($fecha_ini == null)
    $select=mysqli_query($c,"Select * from factura where Fecha_Pago <='$fecha_fin' and Fecha_Pago <> '0000-00-00'");
  else if($fecha_fin == null)
    $select=mysqli_query($c,"Select * from factura where Fecha_Pago >= '$fecha_ini' and Fecha_Pago <> '0000-00-00'");
  else
    $select=mysqli_query($c,"Select * from factura where Fecha_Pago BETWEEN '$fecha_ini' AND '$fecha_fin' and Fecha_Pago <> '0000-00-00'");

   echo "<?xml version='1.0' encoding='UTF-8'?>";

   echo "<XML>"; 

 while($fila=mysqli_fetch_array($select)) {
		
    $numeroFactura=$fila["Numero_Factura"];
    $matricula=$fila["Matricula"];
    $manoDeObra=$fila["Mano_de_Obra"];
    $precioHora=$fila["Precio_Hora"];
    $fechaEmision=$fila["Fecha_Emision"];
    $fechaPago=$fila["Fecha_Pago"];
    $baseImponible=$fila["Base_Imponible"];
    $iva=$fila["IVA"];
    $total=$fila["Total"];
  	
	      echo "<factura>";
        
        echo "<numeroFactura>";
          echo "$numeroFactura";
        echo "</numeroFactura>";

        echo "<manoDeObra>";
          echo "$manoDeObra";
        echo "</manoDeObra>";

        echo "<precioHora>";
        echo "$precioHora";
        echo "</precioHora>";

        echo "<fechaEmision>";
          echo "$fechaEmision";
        echo "</fechaEmision>";

        echo "<fechaPago>";
          echo "$fechaPago";
        echo "</fechaPago>";

        echo "<baseImponible>";
          echo "$baseImponible";
        echo "</baseImponible>";

        echo "<iva>";
          echo "$iva";
        echo "</iva>";

        echo "<total>";
          echo "$total";
        echo "</total>";

        echo "</factura>";
             
			 
		}
    echo "</XML>";
?>    