<?php
session_start();
?>

<!DOCTYPE html>

<html lang="es">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<script src="javascript/js.js" type="text/javascript"></script>
		<script src="javascript/jquery-3.2.0.min.js" type="text/javascript"></script>
		<script src="javascript/funciones.js" type="text/javascript"></script>
		<script src="javascript/funciones_ajax.js" type="text/javascript"></script>
		<title>Talleres Gallego</title>
	</head>
	<body>
	<div class="med">
			<header id="cabecera">
				<img title="Talleres Gallego" src="./img/taller-logo.png" alt="Logo"/>
				<h1>Tu taller de reparaciones de confianza</h1>
			</header>
		 <nav id="menu">
				<ul>
					<li class="submenu">
						<a href="index.php">Inicio</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Pagina principal del sitio web
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_clientes.php">Clientes</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Clientes
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_vehiculos.php">Vehículos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de vehículos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_repuestos.php">Respuestos</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Respuestos
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="gestion_facturas.php">Facturas</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Gestión de Facturas
							</div>
						</div>
					</li>
					<li class="submenu">
						<a href="logout.php">Cerrar Sesión</a>
						<div class="submenu_contenido">
							<div class="leyenda">
								Finalización de la sesión
							</div>
						</div>
					</li>
				</ul>
			</nav>

			<section class="contenido">
				<div class="news">	
				<?php
						if ($_SESSION["login"]!=true)
							header("Location: index.php");

						include "conexion.php";

						if(isset($_GET['update'])) {
							$numerofactura=$_POST["numerofactura"];
							$matricula=$_POST["matricula"];
							$horas=$_POST["horas"];
							$preciohora=$_POST["preciohora"];
							$fechaemision=$_POST["fechaemision"];
							$fechapago=$_POST["fechapago"];
							$baseimponible=$_POST["baseimponible"];
							$iva=$_POST["iva"];
							$total=$_POST["total"];

							$total=0;

							$rs_lineas_fact=mysqli_query($c,"Select * from detalle_factura where numero_factura='$numerofactura'");
							while($fila=mysqli_fetch_array($rs_lineas_fact)) {
								$referencia=$fila["referencia"];
								$unidades=$fila["unidades"];

								$rs_total=mysqli_query($c,"Select * from repuestos where referencia='$referencia'");
								$fila=mysqli_fetch_array($rs_total);
								$importe=$fila["importe"];
								$porcentaje=$fila["porcentaje"];


								$total+= ($importe*$unidades) + ($importe*$unidades)*($porcentaje/100);
							}

							$baseimponible = $total +  ($horas*$preciohora);

							$total_factura = $baseimponible + ($baseimponible*($iva/100));

							$update=mysqli_query($c,"Update factura SET numero_factura='$numerofactura',matricula='$matricula',horas='$horas',precio_hora='$preciohora',fecha_emision='$fechaemision',fecha_pago='$fechapago',base_imponible='$baseimponible',iva='$iva',total='$total_factura' WHERE numero_factura='$numerofactura'");

							if(!$update)
								echo "Error al acceder a la base de datos de facturas.<br>";
							else 
								echo "Actualización realizada con exito.";

							header("Refresh:1; url=gestion_facturas.php");
						}
						else if(isset($_GET['delete'])) {
							$numerofactura=$_POST["numerofactura"];


							$delete=mysqli_query($c,"DELETE from factura WHERE numero_factura='$numerofactura'");
							$delete_detalles=mysqli_query($c,"DELETE from detalle_factura WHERE numero_factura='$numerofactura'");


							if(!$delete || !$delete_detalles)
								echo "Error al acceder a la base de datos de facturas.<br>";
							else 
								echo "Eliminación realizada con exito.";

							header("Refresh:1; url=gestion_facturas.php");
						}
						else if(isset($_GET['multiDelete'])) {
							if(isset($_POST['delete'])){
								$array_borrados=$_POST["delete"];
								$error=0;
								for($i=0;$i<count($array_borrados);$i++)
								{
									$multi_delete=mysqli_query($c,"DELETE from factura WHERE numero_factura='$array_borrados[$i]'");
									$delete_detalles=mysqli_query($c,"DELETE from detalle_factura WHERE numero_factura='$array_borrados[$i]'");

									if($multi_delete==0)
									{
										echo "<br>Error al eliminar las facturas de la base de datos.";
										$error=1;
									}
								}
								if($error==0)
								{
									echo "Las facturas se han eliminado correctamente.";
								}

								header("Refresh:1; url=gestion_facturas.php");
							}
							else{
								echo "Seleccione una factura antes de eliminar.";
								header("Refresh:2; url=gestion_facturas.php");
							}
						}
						else if(isset($_GET['insert'])) {
							if(isset($_POST['numerofactura'])){
								$numerofactura=$_POST["numerofactura"];
								$matricula=$_POST["matricula"];
								$horas=$_POST["horas"];
								$preciohora=$_POST["preciohora"];
								$fechaemision=$_POST["fechaemision"];
								$fechapago=$_POST["fechapago"];
								$baseimponible=$_POST["baseimponible"];
								$iva=$_POST["iva"];
								$total=$_POST["total"];
							
   								$insert=mysqli_query($c,"insert into factura values ('$numerofactura','$matricula','$horas','$preciohora','$fechaemision','$fechapago','$baseimponible','$iva','$total')");

								if(!$insert)
									echo "Error al acceder a la base de datos de facturas.<br>";
								else 
									echo "Insercción realizada con exito.";

								header("Refresh:1; url=gestion_facturas.php");
							}
							else
								header("Location: gestion_facturas.php");
						
						}
						else 
							header("Location: gestion_facturas.php");
						
					?>
				</div>
				
			</section>
			<footer class="footer">
				<p>
					TALLERES GALLEGO, S.L
					CIF:B54970413	
					<br>
					Telf: 965 48 46 68			
				</p>
			</div>
		</div>
	</body>
</html>